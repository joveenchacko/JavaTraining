package com.simbiosys.assign5;

public interface Balanceable {
	
	
	public double getBalance();
	public void setBalance(double balance);

}
