package com.simbiosys.assign5;

public interface Withdrawable{
	
	public void withDraw(double amount);

}
