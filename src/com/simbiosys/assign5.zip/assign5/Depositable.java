package com.simbiosys.assign5;

public interface Depositable {

	public void deposit(double amount);
}
